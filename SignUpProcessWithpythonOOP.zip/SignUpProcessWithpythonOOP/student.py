#! C:\Python36\python.exe
import MySQLdb as mysql
import cgi
import cgitb;cgitb.enable()#enable to track cgi error. cgi tb request for debugging

print("Content-type:text/html\n\n")
class Student: #creating Student class
    def __init__(self,fname,lname,email,gender,address,phone,course): #initialization method
        self.fname = fname
        self.lname = lname
        self.email = email
        self.gender = gender
        self.address = address
        self.phone = phone
        self.course= course

    #inserting students into the database
    def add(self): #It is using Polymorphism features. Because add method from this class is the same as the coursemaster class.
        db = mysql.connect("localhost","root","thihazaw","abclearningcenter") #open database connection
        sql="insert into studentmaster(Student_FirstName, Student_LastName, Email, Gender, Residential_Address, Contact_No, Course_Id) values('{0}','{1}','{2}','{3}','{4}','{5}','{6}')".format(self.fname,self.lname,self.email,self.gender,self.address,self.phone,self.course)
                                                                                                                                                                       
        cursor=db.cursor() #prepare a cursor object using cursor method 
        try:
            cursor.execute(sql)
            db.commit()
            print("""
<!DOCTYPE html>
<html>

<head>
	<title>ABC Learning Center</title>
    <style>
        body {
            margin : 0 ;
            padding: 0 ;
            background-image: url(img/bgp.jfif);
            background-size : cover ;
        }

        .form-area {
            position: absolute ;
            top : 45% ;
            left : 30% ;
            transform: translate(-50%,-50%) ;
            width: 500px ;
            height: 300px;
            box-sizing: border-box;
            background-color: rgba(0, 0, 0, 0.87);
            padding : 40px ;
            margin: 100px 0 100px 0;
        }
        
        h3 {
            margin: 0 ;
            padding: 0 0 20px ;
            font-weight: bolder;
            color: antiquewhite;
        }

.form-area p {
            margin: 0 ;
            padding: 0;
            font-weight: bold ;
            color: rgb(69, 147, 216) ;
        }
    </style>
</head>
	
        <h3>Dear,<b>
 """)
            print(self.fname,self.lname)
            print("""
        </b></h3>
        <p style="font-size:20px;color:#5C5C5C;">Thank you for verifying your Mobile No <b>
 """)
            print(self.phone)
            print("""
        <b>.We have sent you an email <b>
 """)
            print(self.email)
            print("""
		<b> with your details.
</p>

    <br><br>
        </div>
        
	</div>
</div>
</body>
</html>
""")
        except Exception as e:
            print(str(e))                                                                                                                                                                
            db.rollback()
        db.close
