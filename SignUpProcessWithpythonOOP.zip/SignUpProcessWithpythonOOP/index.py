#! C:\Python36\python.exe
import MySQLdb as mysql
import cgi
import cgitb;cgitb.enable()#enable to track cgi error. cgi tb request for debugging
print("Content-type:text/html\n\n")

form=cgi.FieldStorage()
class database: #database class is the super class or base class  
    #defining connect database as a method in the super class
    def connect_db(self):
        db = mysql.connect(host = "localhost",user="root",password="thihazaw",db="abclearningcenter")
        return db
    
class coursemaster(database): #coursemaster class is the sub class inherited from the database class 
        
    #retrieve courses from database and populate dropdown list    
    def get_AllCourses(self):
        cursor.execute("select Course_Id,Course_Name from coursemaster")
        row = cursor.fetchone()
        while row is not None:
            row = cursor.fetchone()

#create C1 object from the coursemaster class  
C1=coursemaster() #sending two arguments to the coursemaster class  
db=C1.connect_db() #calling connect_db method from the super class: database class  
cursor=db.cursor() #prepare a cursor object using cursor method 
#C1.add() #calling add function// It is the porlymorphism because we use the same name of method in the coursemaster class and Student class. But the operations are different.
C1.get_AllCourses() #calling get_AllCourses method from the coursemaster class

print("""
<html>
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Registeration</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="bootstrap-4.3.1-dist/css/bootstrap.min.css">
    <script src="bootstrap-4.3.1-dist/js/bootstrap.min.js"></script>
<title> ABC Learning Center </title>
link
</head>
<body>
<form name='myform' action="submit.py" method="post">
<div class="form-area">
        <h1> ABC Learning Center </h1>
        <h3>Registeration Form</h3>
        <form action="">
            <p>First Name</p>
            <input type="text" name="" id=""placeholder="Enter First Name Here.." class="form-control">
            <div class="col" id="error" style="color:red"></div>
            
            <p>Last Name</p>
            <input type="text" name="" id=""placeholder="Enter Last Name Here.." class="form-control">
            <div class="col" id="error1" style="color:red"></div>

            <p>Gender</p>
            <input type="radio" name="gender" value="Male" id="gd" onblur="blank('gd','error7')" required title=" This field is required"> Male 
            <input type="radio" name="gender" value="Female"> Female <br>
            <div class="col" id="error7" style="color:red"></div>
            <div class="col" id="error6" style="color:red"></div>
            

            <p>Address</p>
            <input type="text" name="" id=""placeholder="Enter Last Resenditial Address.." class="form-control" style="colorwhite">
            <div class="col" id="error3" style="color: red"></div>

            <p>Email Address</p>
            <input type="text" name="" id=""placeholder="Enter Last Email Address.." class="form-control">
            <div class="col" id="error4" style="color:red"></div>
            
            <p>Phone Number</p>
            <input type="text" name="" id=""placeholder="Enter your Phone Number.." class="form-control">
                    

            <p>Courses</p>
            <select id="course"  class="form-control" name="course" onblur="blank('course','error5')"required title=" Must select one course">
                        """)
for (Course_Id, Course_Name) in cursor:
    print('<option value="'+ str(Course_Id)+'">'+ Course_Name +'</option>')
print("""
			   
              </select>
	  <div class="col" id="error5" style="color:red"></div>
                

            <button class="btn btn-primary" id="bt" onclick="myFunction()">Reset</button>

            <input type="submit" class="btn btn-primary" name="SubmitButton" value="Submit" onClick="ValidateForm(this.form)">
            <input type="hidden" name="submitted" value="1">

        </form>
    </div>
  
    
</form>
</body>
		<script type="text/javascript">
		function blank(eid,errid)
		{
		var x=document.getElementById(eid).value;
		if(x=="")
		{
		document.getElementById(errid).innerHTML="<img src='.jpg' title='This is a required field'/> Please fill this field";
		}
		else
		{
		document.getElementById(errid).innerHTML="";
		}
		}
		 
		function checkaplha(event,err)
		{
		if(!((event.which>=65 && event.which<=90) || (event.which>=97 && event.which<=122) || event.which==0 || event.which==8))
		{
		document.getElementById(err).innerHTML="<img src='info.jpg' title='Frist name must not contain numbers'/> Invalid Name Format!";
		return false;
		}
		}
		 
		function emailvalidation(mail) 
		{
			if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(myform.email.value))
			{
				return (true)
			}
			document.getElementById("error2").innerHTML="<img src='info.jpg' title='Email format must be xxx@xx.xxx'/> invalid email format";
			return (false)
		}
		function ValidateForm(form) {
						ErrorText = "";
						if ((form.gender[0].checked == false) && (form.gender[1].checked == false)) {
							document.getElementById("error6").innerHTML = "<img src='info.jpg' title='This is a required field'/> Please choose gender";
						} else {
							document.getElementById("error6").innerHTML = "";
						}
					}

	function phnumbervalidation(evt)
      {
         var charCode = (evt.which) ? evt.which : event.keyCode
         if (charCode > 31 && (charCode < 48 || charCode > 57))
            return false;

         return true;
      }
    function myFunction() {
    location.reload();
}
		</script>
</html>


""")

db.close() #disconnect from the server
